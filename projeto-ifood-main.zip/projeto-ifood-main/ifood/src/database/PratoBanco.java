package database;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;

import database.DBConnection;
import model.Prato;

public class PratoBanco {

    protected DBConnection connection;

    public PratoBanco(DBConnection connection) {
        super();
        this.connection = connection;
    }

    // Método para criar um novo prato
    public void criarPrato(Prato prato) {
        String sql = "INSERT INTO prato(nome, descricao, ingredientes, preco, id_restaurante) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.getConnection().prepareStatement(sql)) {
            stmt.setString(1, prato.getNome());
            stmt.setString(2, prato.getDescricao());
            stmt.setString(3, prato.getIngredientes());
            stmt.setDouble(4, prato.getPreco());
            stmt.setInt(5, prato.getIdRestaurante());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao criar prato", e);
        }
    }

    // Método para visualizar um prato pelo ID
    public Prato visualizarPrato(int id) {
        String sql = "SELECT * FROM prato WHERE id = ?";
        Prato prato = null;

        try (PreparedStatement stmt = connection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                prato = new Prato();
                prato.setId(rs.getInt("id"));
                prato.setNome(rs.getString("nome"));
                prato.setDescricao(rs.getString("descricao"));
                prato.setIngredientes(rs.getString("ingredientes"));
                prato.setPreco(rs.getDouble("preco"));
                prato.setIdRestaurante(rs.getInt("id_restaurante"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao visualizar prato", e);
        }
        return prato;
    }

    // Método para atualizar um prato
    public void atualizarPrato(Prato prato, int id) {
        String sql = "UPDATE prato SET nome = ?, descricao = ?, ingredientes = ?, preco = ?, id_restaurante = ? WHERE id = ?";

        try (PreparedStatement stmt = connection.getConnection().prepareStatement(sql)) {
            stmt.setString(1, prato.getNome());
            stmt.setString(2, prato.getDescricao());
            stmt.setString(3, prato.getIngredientes());
            stmt.setDouble(4, prato.getPreco());
            stmt.setInt(5, prato.getIdRestaurante());
            stmt.setInt(6, id);

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao atualizar prato", e);
        }
    }

    // Método para excluir um prato
    public void excluirPrato(int id) {
        String sql = "DELETE FROM prato WHERE id = ?";

        try (PreparedStatement stmt = connection.getConnection().prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao excluir prato", e);
        }
    }

    // Método para listar todos os pratos
    public List<Prato> listarPratos() {
        List<Prato> pratos = new ArrayList<>();
        String sql = "SELECT * FROM prato WHERE id_restaurante = ?";

        try (Statement stmt = connection.getConnection().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Prato prato = new Prato();
                prato.setId(rs.getInt("id"));
                prato.setNome(rs.getString("nome"));
                prato.setDescricao(rs.getString("descricao"));
                prato.setIngredientes(rs.getString("ingredientes"));
                prato.setPreco(rs.getDouble("preco"));
                prato.setIdRestaurante(rs.getInt("id_restaurante"));
                pratos.add(prato);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao listar pratos", e);
        }
        return pratos;
    }
}
